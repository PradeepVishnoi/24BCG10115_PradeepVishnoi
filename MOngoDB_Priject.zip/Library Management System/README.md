# Library Management System Backend

This is a production-quality backend for a Library Management System, built with Java 21, Spring Boot 3.x, and MongoDB.

## Technologies Used
- Java 21
- Spring Boot 3.2.4
- Spring Web (REST APIs)
- Spring Data MongoDB (Database)
- Lombok (Boilerplate code reduction)
- Jakarta Validation (Data validation)
- Maven (Build tool)

## Project Structure
The project follows a standard Layered Architecture (`Controller -> Service -> Repository`):
- `config`: Setup classes, including the `DataSeeder` which populates MongoDB with initial sample data.
- `controller`: REST API endpoints.
- `service`: Business logic layer.
- `repository`: MongoDB repository interfaces.
- `model`: Document entities (`Book`, `Member`, `BorrowRecord`).
- `dto`: Data Transfer Objects (Request/Response models).
- `exception`: Global Exception Handling (`@RestControllerAdvice`).

## Prerequisites
- Java 21 installed.
- Maven installed.
- MongoDB running locally on `localhost:27017` (or update `application.properties`).

## Getting Started

1. **Clone/Download the repository**.
2. **Start MongoDB**: Ensure MongoDB is running. The application connects to `mongodb://localhost:27017/library_management`.
3. **Run the application**:
   ```bash
   mvn spring-boot:run
   ```
   *Note: On the first run, the `DataSeeder` will automatically populate the database with a few sample Books and Members.*

## API Endpoints

The application uses standard REST conventions and a uniform `ApiResponse<T>` wrapper for all endpoints.

### Books (`/api/books`)
- `GET /api/books` - Get all books (paginated)
- `POST /api/books` - Add a new book
- `GET /api/books/{id}` - Get a book by ID
- `PUT /api/books/{id}` - Update a book
- `DELETE /api/books/{id}` - Delete a book
- `GET /api/books/search` - Search by title, author, category, or isbn

### Members (`/api/members`)
- `GET /api/members` - Get all members (paginated)
- `POST /api/members` - Add a new member
- `GET /api/members/{id}` - Get a member by ID
- `PUT /api/members/{id}` - Update a member
- `DELETE /api/members/{id}` - Delete a member

### Borrow Workflow (`/api`)
- `POST /api/borrow` - Borrow a book
- `POST /api/return/{borrowId}` - Return a book
- `GET /api/borrow/history` - View borrow history (supports filtering by memberId, bookId, and status)

## Testing
A Postman collection `Library_Management_System.postman_collection.json` is included in the root directory. Import this file into Postman to quickly test all available endpoints.
