package com.library.controller;

import com.library.dto.ApiResponse;
import com.library.dto.MemberRequest;
import com.library.dto.MemberResponse;
import com.library.service.MemberService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/members")
@RequiredArgsConstructor
public class MemberController {

    private final MemberService memberService;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ApiResponse<MemberResponse> addMember(@Valid @RequestBody MemberRequest request) {
        MemberResponse response = memberService.addMember(request);
        return ApiResponse.success("Member created successfully", response);
    }

    @GetMapping
    public ApiResponse<Page<MemberResponse>> getAllMembers(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<MemberResponse> response = memberService.getAllMembers(pageable);
        return ApiResponse.success("Members fetched successfully", response);
    }

    @GetMapping("/{id}")
    public ApiResponse<MemberResponse> getMember(@PathVariable String id) {
        MemberResponse response = memberService.getMemberById(id);
        return ApiResponse.success("Member fetched successfully", response);
    }

    @PutMapping("/{id}")
    public ApiResponse<MemberResponse> updateMember(@PathVariable String id, @Valid @RequestBody MemberRequest request) {
        MemberResponse response = memberService.updateMember(id, request);
        return ApiResponse.success("Member updated successfully", response);
    }

    @DeleteMapping("/{id}")
    public ApiResponse<Void> deleteMember(@PathVariable String id) {
        memberService.deleteMember(id);
        return ApiResponse.success("Member deleted successfully", null);
    }
}
