package com.library.controller;

import com.library.dto.ApiResponse;
import com.library.dto.BorrowRequest;
import com.library.dto.BorrowResponse;
import com.library.model.enums.BorrowStatus;
import com.library.service.BorrowService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class BorrowController {

    private final BorrowService borrowService;

    @PostMapping("/borrow")
    @ResponseStatus(HttpStatus.CREATED)
    public ApiResponse<BorrowResponse> borrowBook(@Valid @RequestBody BorrowRequest request) {
        BorrowResponse response = borrowService.borrowBook(request);
        return ApiResponse.success("Book borrowed successfully", response);
    }

    @PostMapping("/return/{borrowId}")
    public ApiResponse<BorrowResponse> returnBook(@PathVariable String borrowId) {
        BorrowResponse response = borrowService.returnBook(borrowId);
        return ApiResponse.success("Book returned successfully", response);
    }

    @GetMapping("/borrow/history")
    public ApiResponse<List<BorrowResponse>> getHistory(
            @RequestParam(required = false) String memberId,
            @RequestParam(required = false) String bookId,
            @RequestParam(required = false) BorrowStatus status) {
        List<BorrowResponse> response = borrowService.getHistory(memberId, bookId, status);
        return ApiResponse.success("Borrow history fetched successfully", response);
    }
}
