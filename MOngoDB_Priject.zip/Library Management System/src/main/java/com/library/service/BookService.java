package com.library.service;

import com.library.dto.BookRequest;
import com.library.dto.BookResponse;
import com.library.exception.DuplicateResourceException;
import com.library.exception.ResourceNotFoundException;
import com.library.exception.ValidationException;
import com.library.model.Book;
import com.library.model.enums.BookStatus;
import com.library.model.enums.BorrowStatus;
import com.library.repository.BookRepository;
import com.library.repository.BorrowRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class BookService {

    private final BookRepository bookRepository;
    private final BorrowRepository borrowRepository;

    public BookResponse addBook(BookRequest request) {
        if (bookRepository.existsByIsbn(request.getIsbn())) {
            throw new DuplicateResourceException("Book with ISBN " + request.getIsbn() + " already exists");
        }

        Book book = Book.builder()
                .title(request.getTitle())
                .author(request.getAuthor())
                .isbn(request.getIsbn())
                .category(request.getCategory())
                .publisher(request.getPublisher())
                .publishedYear(request.getPublishedYear())
                .totalCopies(request.getTotalCopies())
                .availableCopies(request.getTotalCopies())
                .status(BookStatus.AVAILABLE)
                .build();

        Book savedBook = bookRepository.save(book);
        return mapToResponse(savedBook);
    }

    public Page<BookResponse> getAllBooks(Pageable pageable) {
        return bookRepository.findAll(pageable).map(this::mapToResponse);
    }

    public BookResponse getBookById(String id) {
        Book book = bookRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Book not found with id: " + id));
        return mapToResponse(book);
    }

    public BookResponse updateBook(String id, BookRequest request) {
        Book book = bookRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Book not found with id: " + id));

        if (!book.getIsbn().equals(request.getIsbn()) && bookRepository.existsByIsbn(request.getIsbn())) {
            throw new DuplicateResourceException("Book with ISBN " + request.getIsbn() + " already exists");
        }

        // Handle total copies logic
        int borrowedCopies = book.getTotalCopies() - book.getAvailableCopies();
        if (request.getTotalCopies() < borrowedCopies) {
            throw new ValidationException("Total copies cannot be less than currently borrowed copies (" + borrowedCopies + ")");
        }

        book.setTitle(request.getTitle());
        book.setAuthor(request.getAuthor());
        book.setIsbn(request.getIsbn());
        book.setCategory(request.getCategory());
        book.setPublisher(request.getPublisher());
        book.setPublishedYear(request.getPublishedYear());
        book.setTotalCopies(request.getTotalCopies());
        
        // Update available copies
        book.setAvailableCopies(request.getTotalCopies() - borrowedCopies);
        
        if (book.getAvailableCopies() > 0) {
            book.setStatus(BookStatus.AVAILABLE);
        } else {
            book.setStatus(BookStatus.OUT_OF_STOCK);
        }

        Book updatedBook = bookRepository.save(book);
        return mapToResponse(updatedBook);
    }

    public void deleteBook(String id) {
        Book book = bookRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Book not found with id: " + id));

        boolean hasActiveBorrows = !borrowRepository.findByBookIdAndStatus(id, BorrowStatus.BORROWED).isEmpty();
        if (hasActiveBorrows) {
            throw new ValidationException("Cannot delete book. It is currently borrowed by members.");
        }

        bookRepository.delete(book);
    }

    public Page<BookResponse> searchBooks(String title, String author, String category, String isbn, Pageable pageable) {
        if (title != null) {
            return bookRepository.findByTitleContainingIgnoreCase(title, pageable).map(this::mapToResponse);
        } else if (author != null) {
            return bookRepository.findByAuthorContainingIgnoreCase(author, pageable).map(this::mapToResponse);
        } else if (category != null) {
            return bookRepository.findByCategoryContainingIgnoreCase(category, pageable).map(this::mapToResponse);
        } else if (isbn != null) {
            return bookRepository.findByIsbnContainingIgnoreCase(isbn, pageable).map(this::mapToResponse);
        }
        return getAllBooks(pageable);
    }

    private BookResponse mapToResponse(Book book) {
        return BookResponse.builder()
                .id(book.getId())
                .title(book.getTitle())
                .author(book.getAuthor())
                .isbn(book.getIsbn())
                .category(book.getCategory())
                .publisher(book.getPublisher())
                .publishedYear(book.getPublishedYear())
                .totalCopies(book.getTotalCopies())
                .availableCopies(book.getAvailableCopies())
                .status(book.getStatus())
                .createdAt(book.getCreatedAt())
                .updatedAt(book.getUpdatedAt())
                .build();
    }
}
