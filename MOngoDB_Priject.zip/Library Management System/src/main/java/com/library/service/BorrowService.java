package com.library.service;

import com.library.dto.BorrowRequest;
import com.library.dto.BorrowResponse;
import com.library.exception.BookUnavailableException;
import com.library.exception.BorrowNotAllowedException;
import com.library.exception.ResourceNotFoundException;
import com.library.exception.ValidationException;
import com.library.model.Book;
import com.library.model.BorrowRecord;
import com.library.model.Member;
import com.library.model.enums.BookStatus;
import com.library.model.enums.BorrowStatus;
import com.library.model.enums.MemberStatus;
import com.library.repository.BookRepository;
import com.library.repository.BorrowRepository;
import com.library.repository.MemberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class BorrowService {

    private final BorrowRepository borrowRepository;
    private final BookRepository bookRepository;
    private final MemberRepository memberRepository;

    public BorrowResponse borrowBook(BorrowRequest request) {
        Book book = bookRepository.findById(request.getBookId())
                .orElseThrow(() -> new ResourceNotFoundException("Book not found with id: " + request.getBookId()));

        Member member = memberRepository.findById(request.getMemberId())
                .orElseThrow(() -> new ResourceNotFoundException("Member not found with id: " + request.getMemberId()));

        if (member.getStatus() != MemberStatus.ACTIVE) {
            throw new BorrowNotAllowedException("Member is not active");
        }

        if (book.getAvailableCopies() <= 0) {
            throw new BookUnavailableException("Book is currently unavailable");
        }

        // Decrement available copies
        book.setAvailableCopies(book.getAvailableCopies() - 1);
        if (book.getAvailableCopies() == 0) {
            book.setStatus(BookStatus.OUT_OF_STOCK);
        }
        bookRepository.save(book);

        BorrowRecord record = BorrowRecord.builder()
                .bookId(book.getId())
                .memberId(member.getId())
                .borrowDate(LocalDateTime.now())
                .dueDate(LocalDateTime.now().plusDays(request.getDays()))
                .status(BorrowStatus.BORROWED)
                .build();

        BorrowRecord savedRecord = borrowRepository.save(record);
        return mapToResponse(savedRecord);
    }

    public BorrowResponse returnBook(String borrowId) {
        BorrowRecord record = borrowRepository.findById(borrowId)
                .orElseThrow(() -> new ResourceNotFoundException("Borrow record not found with id: " + borrowId));

        if (record.getStatus() == BorrowStatus.RETURNED) {
            throw new ValidationException("Book has already been returned for this record");
        }

        record.setStatus(BorrowStatus.RETURNED);
        record.setReturnDate(LocalDateTime.now());

        BorrowRecord savedRecord = borrowRepository.save(record);

        Book book = bookRepository.findById(record.getBookId())
                .orElseThrow(() -> new ResourceNotFoundException("Book not found with id: " + record.getBookId()));

        // Increment available copies
        book.setAvailableCopies(book.getAvailableCopies() + 1);
        if (book.getAvailableCopies() > 0) {
            book.setStatus(BookStatus.AVAILABLE);
        }
        bookRepository.save(book);

        return mapToResponse(savedRecord);
    }

    public List<BorrowResponse> getHistory(String memberId, String bookId, BorrowStatus status) {
        List<BorrowRecord> records;

        if (memberId != null && status != null) {
            records = borrowRepository.findByMemberIdAndStatus(memberId, status);
        } else if (bookId != null && status != null) {
            records = borrowRepository.findByBookIdAndStatus(bookId, status);
        } else if (memberId != null) {
            records = borrowRepository.findByMemberId(memberId);
        } else if (bookId != null) {
            records = borrowRepository.findByBookId(bookId);
        } else if (status != null) {
            records = borrowRepository.findByStatus(status);
        } else {
            records = borrowRepository.findAll();
        }

        return records.stream().map(this::mapToResponse).collect(Collectors.toList());
    }

    private BorrowResponse mapToResponse(BorrowRecord record) {
        return BorrowResponse.builder()
                .id(record.getId())
                .bookId(record.getBookId())
                .memberId(record.getMemberId())
                .borrowDate(record.getBorrowDate())
                .dueDate(record.getDueDate())
                .returnDate(record.getReturnDate())
                .status(record.getStatus())
                .build();
    }
}
