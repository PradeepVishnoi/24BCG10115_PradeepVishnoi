package com.library.dto;

import com.library.model.enums.MemberStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class MemberResponse {
    private String id;
    private String name;
    private String email;
    private String phone;
    private String address;
    private LocalDateTime membershipDate;
    private MemberStatus status;
}
