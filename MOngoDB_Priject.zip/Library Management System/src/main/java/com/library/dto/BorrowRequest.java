package com.library.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BorrowRequest {
    
    @NotBlank(message = "Book ID is required")
    private String bookId;

    @NotBlank(message = "Member ID is required")
    private String memberId;

    @NotNull(message = "Days are required")
    @Min(value = 1, message = "Borrow days must be at least 1")
    private Integer days;
}
