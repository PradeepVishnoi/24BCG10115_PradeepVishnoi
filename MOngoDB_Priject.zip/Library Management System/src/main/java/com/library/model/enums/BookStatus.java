package com.library.model.enums;

public enum BookStatus {
    AVAILABLE,
    OUT_OF_STOCK
}
