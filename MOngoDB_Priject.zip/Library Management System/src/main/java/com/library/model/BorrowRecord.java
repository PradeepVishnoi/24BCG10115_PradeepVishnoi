package com.library.model;

import com.library.model.enums.BorrowStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Document(collection = "borrow_records")
public class BorrowRecord {
    @Id
    private String id;
    
    private String bookId;
    
    private String memberId;
    
    private LocalDateTime borrowDate;
    
    private LocalDateTime dueDate;
    
    private LocalDateTime returnDate;
    
    private BorrowStatus status;
}
