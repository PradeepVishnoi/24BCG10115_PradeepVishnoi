package com.library.model.enums;

public enum MemberStatus {
    ACTIVE,
    INACTIVE
}
