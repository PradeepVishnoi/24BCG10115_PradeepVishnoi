package com.library.repository;

import com.library.model.BorrowRecord;
import com.library.model.enums.BorrowStatus;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BorrowRepository extends MongoRepository<BorrowRecord, String> {
    List<BorrowRecord> findByBookIdAndStatus(String bookId, BorrowStatus status);
    List<BorrowRecord> findByMemberIdAndStatus(String memberId, BorrowStatus status);
    
    List<BorrowRecord> findByMemberId(String memberId);
    List<BorrowRecord> findByBookId(String bookId);
    List<BorrowRecord> findByStatus(BorrowStatus status);
}
