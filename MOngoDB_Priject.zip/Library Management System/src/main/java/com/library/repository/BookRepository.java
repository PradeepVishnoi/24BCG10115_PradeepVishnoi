package com.library.repository;

import com.library.model.Book;
import com.library.model.enums.BookStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface BookRepository extends MongoRepository<Book, String> {
    Optional<Book> findByIsbn(String isbn);
    
    Page<Book> findByTitleContainingIgnoreCase(String title, Pageable pageable);
    
    Page<Book> findByAuthorContainingIgnoreCase(String author, Pageable pageable);
    
    Page<Book> findByCategoryContainingIgnoreCase(String category, Pageable pageable);
    
    Page<Book> findByIsbnContainingIgnoreCase(String isbn, Pageable pageable);
    
    Page<Book> findByStatus(BookStatus status, Pageable pageable);
    
    boolean existsByIsbn(String isbn);
}
