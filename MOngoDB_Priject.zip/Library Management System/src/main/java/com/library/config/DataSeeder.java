package com.library.config;

import com.library.model.Book;
import com.library.model.Member;
import com.library.model.enums.BookStatus;
import com.library.model.enums.MemberStatus;
import com.library.repository.BookRepository;
import com.library.repository.MemberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

@Component
@RequiredArgsConstructor
public class DataSeeder implements CommandLineRunner {

    private final BookRepository bookRepository;
    private final MemberRepository memberRepository;

    @Override
    public void run(String... args) throws Exception {
        if (bookRepository.count() == 0) {
            System.out.println("Seeding books...");
            bookRepository.saveAll(List.of(
                    Book.builder()
                            .title("The Great Gatsby")
                            .author("F. Scott Fitzgerald")
                            .isbn("9780743273565")
                            .category("Fiction")
                            .publisher("Scribner")
                            .publishedYear(1925)
                            .totalCopies(5)
                            .availableCopies(5)
                            .status(BookStatus.AVAILABLE)
                            .createdAt(LocalDateTime.now())
                            .updatedAt(LocalDateTime.now())
                            .build(),
                    Book.builder()
                            .title("1984")
                            .author("George Orwell")
                            .isbn("9780451524935")
                            .category("Science Fiction")
                            .publisher("Signet Classic")
                            .publishedYear(1949)
                            .totalCopies(3)
                            .availableCopies(3)
                            .status(BookStatus.AVAILABLE)
                            .createdAt(LocalDateTime.now())
                            .updatedAt(LocalDateTime.now())
                            .build()
            ));
        }

        if (memberRepository.count() == 0) {
            System.out.println("Seeding members...");
            memberRepository.saveAll(List.of(
                    Member.builder()
                            .name("John Doe")
                            .email("john.doe@example.com")
                            .phone("1234567890")
                            .address("123 Main St")
                            .membershipDate(LocalDateTime.now())
                            .status(MemberStatus.ACTIVE)
                            .build(),
                    Member.builder()
                            .name("Jane Smith")
                            .email("jane.smith@example.com")
                            .phone("0987654321")
                            .address("456 Elm St")
                            .membershipDate(LocalDateTime.now())
                            .status(MemberStatus.ACTIVE)
                            .build()
            ));
        }
    }
}
