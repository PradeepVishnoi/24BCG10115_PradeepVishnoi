package com.library.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class BorrowNotAllowedException extends RuntimeException {
    public BorrowNotAllowedException(String message) {
        super(message);
    }
}
