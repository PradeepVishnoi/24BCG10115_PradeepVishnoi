# Product Requirements Document (PRD)

## Project Name

**Library Management System**

## 1. Project Overview

Develop a **Library Management System** using:

-   **Backend:** Java 21
-   **Framework:** Spring Boot 3.x
-   **Database:** MongoDB
-   **Build Tool:** Maven
-   **API Testing:** Postman
-   **Architecture:** REST API

This is an educational CRUD project demonstrating Spring Boot
integration with MongoDB.

The application should allow librarians to manage books, members, and
borrowing operations. No frontend is required.

------------------------------------------------------------------------

## 2. Objectives

The system should allow librarians to:

-   Manage books
-   Manage library members
-   Borrow books
-   Return books
-   Track available copies
-   Search books
-   View borrowing history

------------------------------------------------------------------------

## 3. Technology Stack

### Backend

-   Java 21
-   Spring Boot
-   Spring Web
-   Spring Data MongoDB
-   Lombok
-   Jakarta Validation
-   Maven

### Database

Database Name: `library_management`

Collections: - books - members - borrow_records

------------------------------------------------------------------------

## 4. Project Structure

``` text
library-management/
├── controller/
├── service/
├── repository/
├── model/
├── dto/
├── mapper/
├── exception/
├── config/
└── LibraryManagementApplication.java
```

------------------------------------------------------------------------

# 5. Functional Requirements

## Module 1 -- Book Management

### Book Fields

  Field             Type
  ----------------- --------------------------
  id                String
  title             String
  author            String
  isbn              String
  category          String
  publisher         String
  publishedYear     Integer
  totalCopies       Integer
  availableCopies   Integer
  status            AVAILABLE / OUT_OF_STOCK
  createdAt         Date
  updatedAt         Date

### APIs

  Method   Endpoint            Description
  -------- ------------------- ----------------------------
  POST     /api/books          Add Book
  GET      /api/books          Get All Books (Pagination)
  GET      /api/books/{id}     Get Book
  PUT      /api/books/{id}     Update Book
  DELETE   /api/books/{id}     Delete Book
  GET      /api/books/search   Search Books

Search supports: - Title - Author - Category - ISBN

Deletion should fail if the book is currently borrowed.

------------------------------------------------------------------------

## Module 2 -- Member Management

### Member Fields

-   id
-   name
-   email
-   phone
-   address
-   membershipDate
-   status (ACTIVE / INACTIVE)

### APIs

  Method   Endpoint
  -------- -------------------
  POST     /api/members
  GET      /api/members
  GET      /api/members/{id}
  PUT      /api/members/{id}
  DELETE   /api/members/{id}

Deletion should fail if the member has active borrow records.

------------------------------------------------------------------------

## Module 3 -- Borrow Management

### Borrow Record Fields

-   id
-   bookId
-   memberId
-   borrowDate
-   dueDate
-   returnDate
-   status (BORROWED / RETURNED / OVERDUE)

### Borrow Book

**POST** `/api/borrow`

``` json
{
  "bookId": "BOOK_ID",
  "memberId": "MEMBER_ID",
  "days": 14
}
```

Rules: - Book exists - Member exists - Member is ACTIVE - Book has
available copies - Reduce availableCopies by 1 - Create borrow record

### Return Book

**POST** `/api/return/{borrowId}`

Rules: - Mark record RETURNED - Set returnDate - Increase
availableCopies - Update status if copies become available

### Borrow History

`GET /api/borrow/history`

Supports filters: - member - book - status

------------------------------------------------------------------------

# 6. Validation Rules

### Books

-   Title required
-   Author required
-   ISBN unique
-   Total copies \> 0
-   Valid published year

### Members

-   Name required
-   Email unique
-   Valid email
-   Phone required

### Borrow

-   Cannot borrow unavailable books
-   Cannot return an already returned book

------------------------------------------------------------------------

# 7. Exception Handling

Implement a global exception handler.

Custom exceptions: - ResourceNotFoundException -
DuplicateResourceException - BookUnavailableException -
BorrowNotAllowedException - ValidationException

Error Response Example

``` json
{
  "timestamp": "2026-06-18T18:20:10",
  "status": 404,
  "error": "Not Found",
  "message": "Book not found",
  "path": "/api/books/123"
}
```

------------------------------------------------------------------------

# 8. DTO Layer

Create:

-   BookRequest
-   BookResponse
-   MemberRequest
-   MemberResponse
-   BorrowRequest
-   BorrowResponse

Never expose entity models directly.

------------------------------------------------------------------------

# 9. Repository Layer

Repositories: - BookRepository - MemberRepository - BorrowRepository

Custom methods: - findByTitleContainingIgnoreCase() -
findByAuthorContainingIgnoreCase() -
findByCategoryContainingIgnoreCase() - findByStatus() - findByEmail() -
findByIsbn()

------------------------------------------------------------------------

# 10. Service Layer

Business logic belongs only in services.

-   BookService
-   MemberService
-   BorrowService

------------------------------------------------------------------------

# 11. Controller Layer

Controllers: - BookController - MemberController - BorrowController

Use REST best practices.

------------------------------------------------------------------------

# 12. API Response Format

Success

``` json
{
  "success": true,
  "message": "Book created successfully",
  "data": {}
}
```

Error

``` json
{
  "success": false,
  "message": "Book not found"
}
```

------------------------------------------------------------------------

# 13. MongoDB Collections

## books

``` json
{
  "_id":"...",
  "title":"...",
  "author":"...",
  "isbn":"...",
  "category":"...",
  "publisher":"...",
  "publishedYear":2023,
  "totalCopies":10,
  "availableCopies":8,
  "status":"AVAILABLE"
}
```

## members

``` json
{
  "_id":"...",
  "name":"John",
  "email":"john@example.com",
  "phone":"9876543210",
  "status":"ACTIVE"
}
```

## borrow_records

``` json
{
  "_id":"...",
  "bookId":"...",
  "memberId":"...",
  "borrowDate":"...",
  "dueDate":"...",
  "returnDate":null,
  "status":"BORROWED"
}
```

------------------------------------------------------------------------

# 14. Non-Functional Requirements

-   Layered architecture
-   SOLID principles
-   Constructor Dependency Injection
-   Lombok
-   Jakarta Validation
-   Pagination
-   Search
-   Logging
-   Global exception handling
-   Consistent API responses

------------------------------------------------------------------------

# 15. Future Enhancements

-   JWT Authentication
-   Role-based access
-   Fine calculation
-   Email reminders
-   Reservation system
-   Swagger/OpenAPI
-   Docker
-   Unit tests (JUnit & Mockito)

------------------------------------------------------------------------

# 16. Deliverables

Generate:

-   Complete Spring Boot project
-   Maven configuration
-   MongoDB configuration
-   Models
-   DTOs
-   Repositories
-   Services
-   Controllers
-   Exception handling
-   Validation
-   Seed data
-   Postman collection
-   README

------------------------------------------------------------------------

# Prompt for Antigravity

> Build a production-quality Library Management System backend using
> Java 21, Spring Boot 3.x, Maven, and MongoDB. Follow this PRD exactly.
> Use a layered architecture (Controller → Service → Repository), DTOs,
> Lombok, Jakarta Validation, global exception handling, Spring Data
> MongoDB, pagination, searching, clean REST APIs, sample seed data, a
> Postman collection, and a comprehensive README. Ensure the code
> follows SOLID principles and clean architecture.
